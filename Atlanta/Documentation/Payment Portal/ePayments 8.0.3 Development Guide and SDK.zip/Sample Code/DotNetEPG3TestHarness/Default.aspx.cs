﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Epayment3Application.epayment3.webservice;
using Epayment3Application.SSO.webservice;
using System.Collections.Generic;
using System.Xml;

namespace Epayment3Application
{
    public partial class _Default : System.Web.UI.Page
    {
        string enableSSO = null;
        string sessionID = null;
        string agencyID = null;
        string userID = null;
        IList<mapItem> ssoItems = new List<mapItem>();

        protected void Page_Load(object sender, EventArgs e)
        {
            sign();
        }
 
        protected void Button1_Click(object sender, EventArgs e)
        {
            
            EPayments3 ePayments3 = new EPayments3();         
            EPaymentInfo ePaymentInfo = initEpaymentInfo();     
            //1. get web service URL from config data.
            ePayments3.Url = getAdapterURL(ePaymentInfo.configData);
            EPaymentResult result = null;
            if ("Void".Equals(this.method.Text))
            {      
               // 1. makePayment to get trans code for void payment.          
               result =  ePayments3.makePayment(ePaymentInfo);
               ePaymentInfo = initVoidEpaymentInfo(ePaymentInfo.paymentData, ePaymentInfo.configData, result.returnMap);
               //2. void payment
               result = ePayments3.voidPayment(ePaymentInfo);
               
            }else
            {
                result = ePayments3.makePayment(ePaymentInfo);

            }
            this.lbl_Reture.Text = "The web service return code is \""+result.returnCode + "\";The return message is \""+ result.returnMessage + "\";the return map is " +result.returnMap.Length.ToString();
        }

        private EPaymentInfo initEpaymentInfo()
        {
            EPaymentInfo ePaymentInfo = new EPaymentInfo();
            IList<mapItem> paymentData = new List<mapItem>();
            IList<mapItem> configData = new List<mapItem>();
            //1. read sso sessionID and put the session ID to paymentdata.
            setSSOSessionID(paymentData);
            string[] configFiles = null;
            if ("CreditCard".Equals(this.MethodType.Text))
            {
                configFiles = getCreditCardConfigFiles();
            }
            else
            {
                configFiles = getCheckConfigFiles();
            }
            //1. init payment data from config file
            initPaymentDataFromConfigXml(paymentData, configFiles[0]);
            //2. init config data from config file.
            initConfigDataFromConfigXml(configData, configFiles[1]);
            ePaymentInfo.paymentData = paymentData.ToArray();
            ePaymentInfo.configData = configData.ToArray();
            return ePaymentInfo;
        }

        private string getAdapterURL(IList<mapItem> configData)
        {
            string adapterURL = getValue(configData, "AdapterURL");
            if (adapterURL.EndsWith("?wsdl"))
            {
              adapterURL = adapterURL.Substring(0, adapterURL.Length-5);
            }
            return adapterURL;
        }

        private EPaymentInfo initVoidEpaymentInfo(IList<mapItem> paymentData, IList<mapItem> configData, mapItem[] returnMap)
        {
            IList<mapItem> voidPaymentData = new List<mapItem>();
            EPaymentInfo ePaymentInfo = new EPaymentInfo();
            putValue(voidPaymentData, "TransCode", getValue(returnMap, "TransCode"));
            putValue(voidPaymentData, "AgencyID", getValue(paymentData, "AgencyID"));
            putValue(voidPaymentData, "UserID", getValue(paymentData, "UserID"));
			if (isEnableSSO())
			{
				putValue(voidPaymentData, "UserSessionID", getValue(paymentData, "UserSessionID"));
			}
            ePaymentInfo.configData = configData.ToArray();
            ePaymentInfo.paymentData = voidPaymentData.ToArray();
            return ePaymentInfo;
        }

        private String[] getCreditCardConfigFiles()
        {   
            string[] configFiles = new string[2];
            string epaymentType = this.epaymentType.Text.Trim();
            if (epaymentType != string.Empty)
            {

                    configFiles[0] = "CreditCardPaymentData.xml";
                    configFiles[1] = "CreditCardConfigData.xml";     
            }
            return configFiles;
        }

        private String[] getCheckConfigFiles()
        {
            string[] configFiles = new string[2];
            string epaymentType = this.epaymentType.Text.Trim();
            if (epaymentType != string.Empty)
            {
                    configFiles[0] = "CheckPaymentData.xml";
                    configFiles[1] = "CheckConfigData.xml";
               
            }
            return configFiles;
        }

        private void sign()
        {
            string epaymentType = this.epaymentType.Text.Trim();
            readXmlData(ssoItems, "config\\" + epaymentType + "\\SSOConfig.xml"); 
            agencyID = getValue(ssoItems, "AgencyID");
            userID = getValue(ssoItems, "UserID");
            string password = getValue(ssoItems, "Password");
            
            if (isEnableSSO())
            {  
			   SSOWebServiceService ssoWebService = new SSOWebServiceService();
               ssoWebService.Url = getValue(ssoItems, "AdapterURL");
               sessionID = ssoWebService.signon(agencyID, userID, password);
            }
        }

        private void setSSOSessionID(IList<mapItem> paymentData)
        {
            if (isEnableSSO())
            {
                putValue(paymentData, "UserSessionID", sessionID);
            }
            putValue(paymentData, "AgencyID", agencyID);
            putValue(paymentData, "UserID", userID);
        }

        private void initPaymentDataFromConfigXml(IList<mapItem> paymentData,string paymentFile)
        {
            string epaymentType = this.epaymentType.Text.Trim();
            readXmlData(paymentData, "config\\" + epaymentType +"\\" + paymentFile);
        }

        private void initConfigDataFromConfigXml(IList<mapItem> configData,string configFile)
        {
            string epaymentType = this.epaymentType.Text.Trim();
            readXmlData(configData, "config\\" + epaymentType + "\\" + configFile);
        }


        private void readXmlData(IList<mapItem> mapItems,string configXmlPath)
        {
            XmlDocument doc = new XmlDocument();
            configXmlPath = Server.MapPath(configXmlPath);
            
            doc.Load(configXmlPath);
            XmlNode itemNode = doc.DocumentElement;
            foreach   (XmlNode   node   in   itemNode) 
            {
                putValue(mapItems, node.Attributes["key"].Value, node.InnerText);
            }
        }

        private string getValue(IList<mapItem> mapItems , string key)
        {   
            string result=null;
            foreach (mapItem item in mapItems)
            {
                if (key.Equals(item.key))
                {
                    result = item.value.ToString();
                }
            }
            return result;       
        }

        private void putValue(IList<mapItem> mapItems, string key,string value)
        {
            mapItem item = new mapItem();
            item.key = key;
            item.value = value;
            mapItems.Add(item);
        }

        private bool isEnableSSO()
		{
            enableSSO = getValue(ssoItems, "Enable");		
		      bool result = false;
		      if (enableSSO != null)
            {   
			   if ("true".ToLower().Equals(enableSSO.ToLower()))
			   {
			     result = true;
			   }
			}
          return result;			
		}
    }
}
