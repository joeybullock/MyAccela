﻿/**
 * <pre>
 *
 *  Accela Citizen Access
 *  File: Reference.cs
 *
 *  Accela, Inc.
 *  Copyright (C): 2013
 *
 *  Description:
 *
 *  Notes:
 * </pre>
 */

#pragma warning disable 1591

namespace Epayment3Application.epayment3.webservice {
    using System;
    using System.Web.Services;
    using System.Diagnostics;
    using System.Web.Services.Protocols;
    using System.ComponentModel;
    using System.Xml.Serialization;
    
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30319.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Web.Services.WebServiceBindingAttribute(Name="EPayments3SoapBinding", Namespace="http://service.ws.accela.com")]
    public partial class EPayments3 : System.Web.Services.Protocols.SoapHttpClientProtocol {
        
        private System.Threading.SendOrPostCallback makePaymentOperationCompleted;
        
        private System.Threading.SendOrPostCallback voidPaymentOperationCompleted;
        
        private bool useDefaultCredentialsSetExplicitly;
        
        /// <remarks/>
        public EPayments3() {
            this.Url = global::Epayment3Application.Properties.Settings.Default.Epayment3Application_epayment3_webservice_EPayments3;
            if ((this.IsLocalFileSystemWebService(this.Url) == true)) {
                this.UseDefaultCredentials = true;
                this.useDefaultCredentialsSetExplicitly = false;
            }
            else {
                this.useDefaultCredentialsSetExplicitly = true;
            }
        }
        
        public new string Url {
            get {
                return base.Url;
            }
            set {
                if ((((this.IsLocalFileSystemWebService(base.Url) == true) 
                            && (this.useDefaultCredentialsSetExplicitly == false)) 
                            && (this.IsLocalFileSystemWebService(value) == false))) {
                    base.UseDefaultCredentials = false;
                }
                base.Url = value;
            }
        }
        
        public new bool UseDefaultCredentials {
            get {
                return base.UseDefaultCredentials;
            }
            set {
                base.UseDefaultCredentials = value;
                this.useDefaultCredentialsSetExplicitly = true;
            }
        }
        
        /// <remarks/>
        public event makePaymentCompletedEventHandler makePaymentCompleted;
        
        /// <remarks/>
        public event voidPaymentCompletedEventHandler voidPaymentCompleted;
        
        /// <remarks/>
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://service.ws.accela.com/EPayments3/makePayment", RequestNamespace="http://service.ws.accela.com", ResponseNamespace="http://service.ws.accela.com", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Wrapped)]
        [return: System.Xml.Serialization.XmlElementAttribute("makePaymentReturn")]
        public EPaymentResult makePayment(EPaymentInfo paymentInfo) {
            object[] results = this.Invoke("makePayment", new object[] {
                        paymentInfo});
            return ((EPaymentResult)(results[0]));
        }
        
        /// <remarks/>
        public void makePaymentAsync(EPaymentInfo paymentInfo) {
            this.makePaymentAsync(paymentInfo, null);
        }
        
        /// <remarks/>
        public void makePaymentAsync(EPaymentInfo paymentInfo, object userState) {
            if ((this.makePaymentOperationCompleted == null)) {
                this.makePaymentOperationCompleted = new System.Threading.SendOrPostCallback(this.OnmakePaymentOperationCompleted);
            }
            this.InvokeAsync("makePayment", new object[] {
                        paymentInfo}, this.makePaymentOperationCompleted, userState);
        }
        
        private void OnmakePaymentOperationCompleted(object arg) {
            if ((this.makePaymentCompleted != null)) {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.makePaymentCompleted(this, new makePaymentCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }
        
        /// <remarks/>
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://service.ws.accela.com/EPayments3/voidPayment", RequestNamespace="http://service.ws.accela.com", ResponseNamespace="http://service.ws.accela.com", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Wrapped)]
        [return: System.Xml.Serialization.XmlElementAttribute("voidPaymentReturn")]
        public EPaymentResult voidPayment(EPaymentInfo paymentInfo) {
            object[] results = this.Invoke("voidPayment", new object[] {
                        paymentInfo});
            return ((EPaymentResult)(results[0]));
        }
        
        /// <remarks/>
        public void voidPaymentAsync(EPaymentInfo paymentInfo) {
            this.voidPaymentAsync(paymentInfo, null);
        }
        
        /// <remarks/>
        public void voidPaymentAsync(EPaymentInfo paymentInfo, object userState) {
            if ((this.voidPaymentOperationCompleted == null)) {
                this.voidPaymentOperationCompleted = new System.Threading.SendOrPostCallback(this.OnvoidPaymentOperationCompleted);
            }
            this.InvokeAsync("voidPayment", new object[] {
                        paymentInfo}, this.voidPaymentOperationCompleted, userState);
        }
        
        private void OnvoidPaymentOperationCompleted(object arg) {
            if ((this.voidPaymentCompleted != null)) {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.voidPaymentCompleted(this, new voidPaymentCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }
        
        /// <remarks/>
        public new void CancelAsync(object userState) {
            base.CancelAsync(userState);
        }
        
        private bool IsLocalFileSystemWebService(string url) {
            if (((url == null) 
                        || (url == string.Empty))) {
                return false;
            }
            System.Uri wsUri = new System.Uri(url);
            if (((wsUri.Port >= 1024) 
                        && (string.Compare(wsUri.Host, "localHost", System.StringComparison.OrdinalIgnoreCase) == 0))) {
                return true;
            }
            return false;
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://epayments.service.accela.com")]
    public partial class EPaymentInfo {
        
        private mapItem[] paymentDataField;
        
        private mapItem[] configDataField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(IsNullable=true)]
        [System.Xml.Serialization.XmlArrayItemAttribute("item")]
        public mapItem[] paymentData {
            get {
                return this.paymentDataField;
            }
            set {
                this.paymentDataField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(IsNullable=true)]
        [System.Xml.Serialization.XmlArrayItemAttribute("item")]
        public mapItem[] configData {
            get {
                return this.configDataField;
            }
            set {
                this.configDataField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://epayments.service.accela.com")]
    public partial class mapItem {
        
        private object keyField;
        
        private object valueField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable=true)]
        public object key {
            get {
                return this.keyField;
            }
            set {
                this.keyField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable=true)]
        public object value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://epayments.service.accela.com")]
    public partial class EPaymentResult {
        
        private string returnCodeField;
        
        private mapItem[] returnMapField;
        
        private string returnMessageField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable=true)]
        public string returnCode {
            get {
                return this.returnCodeField;
            }
            set {
                this.returnCodeField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(IsNullable=true)]
        [System.Xml.Serialization.XmlArrayItemAttribute("item")]
        public mapItem[] returnMap {
            get {
                return this.returnMapField;
            }
            set {
                this.returnMapField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable=true)]
        public string returnMessage {
            get {
                return this.returnMessageField;
            }
            set {
                this.returnMessageField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30319.1")]
    public delegate void makePaymentCompletedEventHandler(object sender, makePaymentCompletedEventArgs e);
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30319.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class makePaymentCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs {
        
        private object[] results;
        
        internal makePaymentCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState) : 
                base(exception, cancelled, userState) {
            this.results = results;
        }
        
        /// <remarks/>
        public EPaymentResult Result {
            get {
                this.RaiseExceptionIfNecessary();
                return ((EPaymentResult)(this.results[0]));
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30319.1")]
    public delegate void voidPaymentCompletedEventHandler(object sender, voidPaymentCompletedEventArgs e);
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30319.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class voidPaymentCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs {
        
        private object[] results;
        
        internal voidPaymentCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState) : 
                base(exception, cancelled, userState) {
            this.results = results;
        }
        
        /// <remarks/>
        public EPaymentResult Result {
            get {
                this.RaiseExceptionIfNecessary();
                return ((EPaymentResult)(this.results[0]));
            }
        }
    }
}

#pragma warning restore 1591