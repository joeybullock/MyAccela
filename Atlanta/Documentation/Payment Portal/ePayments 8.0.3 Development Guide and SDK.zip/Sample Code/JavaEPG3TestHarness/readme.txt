This test harness runs from the command prompt. It will read the configuration and test files stored in the resource directory 
and then test all of the EPayments Gateway 3 (epg3) calls, Make Credit Card Payment, Void Credit Card Payment, Make Check Payment, and Void Check Payment.
This test harness will work with any EPG3 Web Service Adapter. It will also test EPG3 Adapters built into the av.biz Business Application Server.

Requirments:
Ant 1.7.0 or Ant 1.7.1
Java JDK 5 or 6

All other required jar files and junit test code has been included.

Configuration Steps.
1. Download and install Ant and the Java JDK
2. Update SetEnv.cmd to contain the correct folder path for ANT_HOME and JAVA_HOME
3. Prepare the configuration resources and test data for your EPG3 Test harness. Be sure to set up the proper test URL.
	a. conf/[ResourceName]/CreditCardConfigData.xml
	b. conf/[ResourceName]/CreditCardPaymentData.xml
	c. conf/[ResourceName]/CheckPaymentData.xml
	d. conf/[ResourceName]/CheckConfigData.xml
4. Configure conf/[ResourceName]/SSOConfig.xml
	a. Set "Enable" to false unless you are testing an internal EPG3 adapter on av.biz.
	b. Set "Enable to true if you are testing an internal EPG3 adapter on av.biz. Also set the user login parameters and the SSO Url.
	
How to run.
1. Go to a command prompt
2. cd to the directory the test harness home directory, e.g. d:\epg3\EPG3TestHarnessInJavaCXF
3. Run the program with the Resource you are testing: RunUT SampleJavaPayPal43

How to review the test results
1. cd to the reports directory, e.g. cd d:\epg3\EPG3TestHarnessInJavaCXF\reports\junit-html
2. open index.html in a browser.

== How to generate a report
Step1. Configuration JDK and ANT environment in setenv.bat.
Step2. Configuration webservice URL
	(1)If the payment gateway need sso authentication, the SSOConfig.xml need to be changed(Enable should be "true") in resource folder
	(2)Change the payment gateway URL in the PayPal43ConfigData.xml and PayPal43ConfigData_Check.xml and STPConfigData.xml from resource folder for the particlar payment
Step3. Click runUT.bat and it's will generate a report in report folder.

==How remove temporary files for a new test.
Run CleanProject.cmd

