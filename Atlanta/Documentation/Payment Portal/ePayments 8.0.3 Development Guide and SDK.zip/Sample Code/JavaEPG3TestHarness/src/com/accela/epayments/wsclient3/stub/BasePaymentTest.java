package com.accela.epayments.wsclient3.stub;

import java.io.FileInputStream;
import java.net.URL;
import java.util.Properties;

import javax.xml.namespace.QName;

import junit.framework.TestCase;

import com.accela.service.epayments.EPaymentInfo;
import com.accela.service.epayments.Map;
import com.accela.ws.service.EPayments3;
import com.accela.ws.service.EPayments3Locator;
import com.accela.ws.service.SSO;
import com.accela.ws.service.SSOServiceLocator;
import com.accela.ws.util.MapUtils;
import com.accela.ws.util.PaymentConstants;

/**
 * <pre>
 * 
 * Accela Automation
 * File: BasePaymentTest.java
 * 
 * Accela, Inc.
 * Copyright (C): 2013
 * 
 * Description:
 * 
 * 
 * </pre>
 */

public abstract class BasePaymentTest extends TestCase
{

	private static final String PROPERTIES_LEVEL_TYPE = "properties.levelType";

	private static final QName SERVICE_NAME = new QName("http://service.ws.accela.com", "EPayments3");

	public static final String PAYMENT_TYPE = "PaymentType";

	/** The Constant CREDIT_CARD. */
	public static final String CREDIT_CARD = "CC";

	/** The Constant CHECK. */
	public static final String CHECK = "EC";

	double payAmount = 100;

	protected String wsurl;

	protected EPayments3 wsClient;

	Map configData;

	Map paymentData;

	/** The credit card mapping. */
	public static final Properties creditCardProperties = new Properties();

	/** The check mapping. */
	public static final Properties checkProperties = new Properties();

	/** The credit card mapping. */
	public static final Properties configDataProperties = new Properties();

	public static final Properties ssoDataProperties = new Properties();

	public static final String PROPERTIES_FILE_PATH = "properties.file.path";

	public static final String PAYPAL43 = "PayPal43";

	public static final String USER_ID = "UserID";

	public static final String AGENCY_ID = "AgencyID";

	public static final String USER_SESSION_ID = "UserSessionID";

	/** The session id. */
	public static String sessionID = null;

	public static String confPath = System.getProperty(PROPERTIES_FILE_PATH) + "/conf";

	/** The level type. */
	public static String levelType = System.getProperty(PROPERTIES_LEVEL_TYPE);

	static
	{
		levelType = System.getProperty(PROPERTIES_LEVEL_TYPE);
		if (levelType == null)
		{
			levelType = PAYPAL43;
		}
		try
		{
			ssoDataProperties.loadFromXML(new FileInputStream(confPath + "/" + levelType + "/SSOConfig.xml"));
			initSSOSessionID();
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void initService() throws Exception
	{
		wsurl = MapUtils.getValue(configData, "AdapterURL"); // .get("AdapterURL");
		URL wsdlURL = new URL(wsurl);
		EPayments3Locator ss = new EPayments3Locator(wsdlURL, SERVICE_NAME);
		wsClient = ss.getEPayments3Port();

	}

	public void readDataFromFile(Properties props, Map map)
	{
		for (Object keyitem : props.keySet())
		{
			String key = keyitem.toString();
			String value = props.getProperty(key);
			MapUtils.putItem(map, key, value);
		}
	}

	public void initConfigData() throws Exception
	{
		configData = new Map();
		readDataFromFile(configDataProperties, configData);
		this.initService();
	}

	private static void initSSOSessionID() throws Exception
	{
		try
		{
			if (isSSOEnabled())
			{   
				String agencyID	= ssoDataProperties.getProperty("AgencyID");
				String userID 	= ssoDataProperties.getProperty("UserID");
				String password	= ssoDataProperties.getProperty("Password");
				String ssoURL	= ssoDataProperties.getProperty("AdapterURL");
				System.out.println("Authenticating SSO Session AgencyID:"+agencyID+ " UserID:"+ userID + " SSOURL:" + ssoURL);

				SSOServiceLocator locator = new SSOServiceLocator();
				URL url =new URL(ssoURL);
				SSO sso = locator.getSSOService(url);
				sessionID = sso.signon(agencyID, userID, password);
				System.out.println("Successfully Authenticated SSO");
			}
		}
		catch (Exception e)
		{
			System.out.println("Could not Authenticate SSO");
			e.printStackTrace();
			throw e;
		}
	}

	public void loadCreditCardConfigFiles() throws Exception
	{
		try
		{
			configDataProperties.loadFromXML(new FileInputStream(confPath + "/" + levelType + "/CreditCardConfigData.xml"));
			creditCardProperties.loadFromXML(new FileInputStream(confPath + "/" + levelType + "/CreditCardPaymentData.xml"));
		}
		catch (Exception e)
		{
			System.err.println("Error Loading Credit Card Property Data for " + levelType);
			throw e;
		}
	}

	public void loadCheckConfigFiles() throws Exception
	{
		try
		{
			configDataProperties.loadFromXML(new FileInputStream(confPath + "/" + levelType + "/CheckConfigData.xml"));
			checkProperties.loadFromXML(new FileInputStream(confPath + "/" + levelType + "/CheckPaymentData.xml"));
		}
		catch (Exception e)
		{
			throw e;
		}
	}

	public EPaymentInfo initVoidEpaymentInfo(Map returnMap)
	{
		EPaymentInfo paymentInfo = new EPaymentInfo();
		Map voidPaymentMap = new Map();
		MapUtils.putItem(voidPaymentMap, PaymentConstants.TRANS_CODE, MapUtils.getValue(returnMap,
			PaymentConstants.TRANS_CODE));
		MapUtils.putItem(voidPaymentMap, AGENCY_ID, ssoDataProperties.getProperty(AGENCY_ID));
		MapUtils.putItem(voidPaymentMap, USER_ID, ssoDataProperties.getProperty(USER_ID));
		if (isSSOEnabled())
		{
			MapUtils.putItem(voidPaymentMap, USER_SESSION_ID, sessionID);
		}
		paymentInfo.setConfigData(configData);
		paymentInfo.setPaymentData(voidPaymentMap);
		return paymentInfo;
	}
	
	public static boolean isSSOEnabled()
	{
		String enableSSO = ssoDataProperties.getProperty("Enable");
		boolean result = false;
		if (enableSSO != null)
		{  
			if ("true".equals(enableSSO.toLowerCase()))
			{
				result = true;
			}
		}
		return result;
	}

}
