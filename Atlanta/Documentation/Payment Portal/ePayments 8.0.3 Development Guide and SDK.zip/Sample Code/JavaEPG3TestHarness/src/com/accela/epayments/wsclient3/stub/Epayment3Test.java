package com.accela.epayments.wsclient3.stub;

import java.util.Properties;

import com.accela.service.epayments.EPaymentInfo;
import com.accela.service.epayments.EPaymentResult;
import com.accela.service.epayments.Map;
import com.accela.ws.util.MapUtils;
import com.accela.ws.util.PaymentConstants;

/**
 * <pre>
 * 
 * Accela Automation
 * File: Epayment3Test.java
 * 
 * Accela, Inc.
 * Copyright (C): 2013
 * 
 * Description:
 * 
 * </pre>
 */
public class Epayment3Test extends BasePaymentTest
{

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.accela.epayments.wsclient3.stub.BasePaymentTest#initConfigData()
	 */
	public void initConfigData() throws Exception
	{
		configData = new Map();
		readDataFromFile(configDataProperties, configData);
		this.initService();
	}

	/**
	 * Test make payment.
	 */
	public void testMakePayment()
	{

		try
		{
			EPaymentInfo paymentInfo = initCreditCardEpaymentInfo();
			EPaymentResult result = wsClient.makePayment(paymentInfo);
			assertEquals("the ChargeCreditCard reult code", "0", result.getReturnCode());
		}
		catch (Exception e)
		{
			e.printStackTrace();
			fail("error::" + e.toString());
		}
	}

	/**
	 * Test void payment.
	 */
	public void testVoidPayment()
	{

		try
		{
			EPaymentInfo paymentInfo = initCreditCardEpaymentInfo();
			EPaymentResult result = wsClient.makePayment(paymentInfo);
			// void payment and get TRANS_CODE from makepayment and put it in
			// void payment data.
			paymentInfo = initVoidEpaymentInfo(result.getReturnMap());
			result = wsClient.voidPayment(paymentInfo);
			assertEquals("the  void ChargeCreditCard reult code", "0", result.getReturnCode());

		}
		catch (Exception e)
		{
			e.printStackTrace();
			fail("error::" + e.toString());
		}
	}

	/**
	 * Test make payment4 check.
	 */
	public void testMakePayment4Check()
	{
		try
		{
			EPaymentInfo paymentInfo = initCheckPaymentData();
			EPaymentResult result = wsClient.makePayment(paymentInfo);
			assertEquals("the check make payment reult code", "0", result.getReturnCode());
		}
		catch (Exception e)
		{
			e.printStackTrace();
			fail("error::" + e.toString());
		}
	}

	/**
	 * Test void4 check.
	 */
	public void testVoid4Check()
	{
		try
		{
			EPaymentInfo paymentInfo = initCheckPaymentData();
			EPaymentResult result = wsClient.makePayment(paymentInfo);
			// The Transaction code returned by makePayment, if system needs to
			// void this transaction, send this value to server
			paymentInfo = initVoidEpaymentInfo(result.getReturnMap());
			result = wsClient.voidPayment(paymentInfo);
			assertEquals("the  void check payment reult code", "0", result.getReturnCode());
		}
		catch (Exception e)
		{
			e.printStackTrace();
			fail("error::" + e.toString());
		}
	}

	/**
	 * Inits the check payment data.
	 * 
	 * @return the e payment info
	 * 
	 * @throws Exception the exception
	 */
	private EPaymentInfo initCheckPaymentData() throws Exception
	{

		// 1. load check payment data from config file
		loadCheckConfigFiles();
		EPaymentInfo paymentInfo = initEpaymentInfo(checkProperties);
		//set paymentType.
		MapUtils.putItem(paymentInfo.getPaymentData(), PaymentConstants.PAYMENT_TYPE, "EC");
		return paymentInfo;
	}

	/**
	 * Inits the credit card epayment info.
	 * 
	 * @return the e payment info
	 * 
	 * @throws Exception the exception
	 */
	private EPaymentInfo initCreditCardEpaymentInfo() throws Exception
	{
		// 1. load creditCard payment data from config file
		loadCreditCardConfigFiles();
		EPaymentInfo paymentInfo = initEpaymentInfo(creditCardProperties);
		MapUtils.putItem(paymentInfo.getPaymentData(), PaymentConstants.PAYMENT_TYPE, "CC");
		return paymentInfo;
	}

	private EPaymentInfo initEpaymentInfo(Properties configProperties) throws Exception
	{

		EPaymentInfo paymentInfo = new EPaymentInfo();
		paymentData = new Map();
		// 1. load config data from config file
		initConfigData();
		readDataFromFile(configProperties, paymentData);
		// 2. get SSO session ID and set sessionID to paymentData
		if (isSSOEnabled())
		{
			MapUtils.putItem(paymentData, USER_SESSION_ID, sessionID);
		}
		paymentInfo.setPaymentData(paymentData);
		paymentInfo.setConfigData(configData);
		return paymentInfo;
	}
}

/*
 * $Log: av-env.bat,v $
 */