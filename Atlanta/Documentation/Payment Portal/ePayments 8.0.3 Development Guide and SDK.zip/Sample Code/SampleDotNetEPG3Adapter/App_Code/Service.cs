/**
 * <pre>
 *
 *  Accela Citizen Access
 *  File: Service.cs
 *
 *  Accela, Inc.
 *  Copyright (C): 2013
 *
 *  Description:
 *
 *  Notes:
 * </pre>
 */

using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[WebService(Namespace = "http://service.ws.accela.com", Name = "EPayments3")]

[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]


    public class Service : IEPayments3SoapBinding
    {
        #region IEPayments3SoapBinding Members
        public EPaymentResult makePayment(EPaymentInfo paymentInfo)
        {
            if (paymentInfo.configData.Length < 0)
            {
                throw new Exception("configData can not be empty!!");
            }

            if (paymentInfo.paymentData.Length < 0)
            {
                throw new Exception("paymentData can not be empty!!");
            }
            
            //Begin Implemention for EPayment
           

            //End Implemention for EPayment  

            
            //Ready to return data to client
            EPaymentResult result = new EPaymentResult();
            result.returnCode = "0";  //0 for successful
            result.returnMessage = "success"; //return message

            mapItem[] mapItems = new mapItem[2];
            mapItems[0] = new mapItem();
            mapItems[0].key = "AuthCode";  //Auth Code. UI may display it, it can be empty or whatever.
            mapItems[0].value = "001012";
            
            mapItems[1] = new mapItem();
            mapItems[1].key = "TransCode"; //Transaction code, return it for void this transaction, requried
            mapItems[1].value = "123456";
            
            result.returnMap = mapItems; // required
            
            return result;

        }

        public EPaymentResult voidPayment(EPaymentInfo paymentInfo)
        {
            if (paymentInfo.configData.Length < 0)
            {
                throw new Exception("configData is not empty!!");
            }

            if (paymentInfo.paymentData.Length < 0)
            {
                throw new Exception("paymentData is not empty!!");
            }
            //The Transaction code returned by makePayment, if system needs to void this transaction, send this value to server.
            mapItem[] paymentData = paymentInfo.paymentData;
            Boolean isExstingTransCode = false;
            for (int i = 0; i < paymentData.Length; i++)
            {
                mapItem mapItem = paymentData[i];
                if (mapItem.key.Equals("TransCode"))
                {
                    isExstingTransCode = true;
                    break;
                }
            }
            if (!isExstingTransCode)
            {
                throw new Exception("TransCode is required when voidpayment");
            }
            //Begin Implemention for EPayment



            //End Implemention for EPayment     
            

            //Ready to return data to client
            EPaymentResult result = new EPaymentResult();
            result.returnCode = "0";  //0 for successful
            result.returnMessage = "success"; //return message

            mapItem[] mapItems = new mapItem[1];
            mapItems[0] = new mapItem();
            mapItems[0].key = "AuthCode";  //Auth Code.
            mapItems[0].value = "001012";
           
            result.returnMap = mapItems; // required

            
            return result;
        }
        #endregion
    }

    

