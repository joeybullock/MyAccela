
package com.accela.service.epayments;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <pre>
 * 
 * Accela Automation
 * File: EPaymentInfo.java
 * 
 * Accela, Inc.
 * Copyright (C): 2013
 * 
 * Description:
 * 
 * 
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EPaymentInfo", propOrder = {
    "paymentData",
    "configData"
})
public class EPaymentInfo {

    /** The payment data. */
    @XmlElement(required = true, nillable = true)
    protected Map paymentData;
    
    /** The config data. */
    @XmlElement(required = true, nillable = true)
    protected Map configData;

    /**
     * Gets the value of the paymentData property.
     * 
     * @return the payment data
     * 
     * possible object is
     * {@link Map }
     */
    public Map getPaymentData() {
        return paymentData;
    }

    /**
     * Sets the value of the paymentData property.
     * 
     * @param value allowed object is
     * {@link Map }
     */
    public void setPaymentData(Map value) {
        this.paymentData = value;
    }

    /**
     * Gets the value of the configData property.
     * 
     * @return the config data
     * 
     * possible object is
     * {@link Map }
     */
    public Map getConfigData() {
        return configData;
    }

    /**
     * Sets the value of the configData property.
     * 
     * @param value allowed object is
     * {@link Map }
     */
    public void setConfigData(Map value) {
        this.configData = value;
    }

}
