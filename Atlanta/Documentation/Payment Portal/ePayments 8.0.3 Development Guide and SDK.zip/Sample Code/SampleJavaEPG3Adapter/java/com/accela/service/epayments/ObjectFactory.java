
package com.accela.service.epayments;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * <pre>
 * 
 * Accela Automation
 * File: ObjectFactory.java
 * 
 * Accela, Inc.
 * Copyright (C): 2013
 * 
 * Description:
 * 
 * 
 * </pre>
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.accela.service.epayments
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link MapItem }
     * 
     */
    public MapItem createMapItem() {
        return new MapItem();
    }

    /**
     * Create an instance of {@link Map }
     * 
     */
    public Map createMap() {
        return new Map();
    }

    /**
     * Create an instance of {@link EPaymentResult }
     * 
     */
    public EPaymentResult createEPaymentResult() {
        return new EPaymentResult();
    }

    /**
     * Create an instance of {@link EPaymentInfo }
     * 
     */
    public EPaymentInfo createEPaymentInfo() {
        return new EPaymentInfo();
    }

}
