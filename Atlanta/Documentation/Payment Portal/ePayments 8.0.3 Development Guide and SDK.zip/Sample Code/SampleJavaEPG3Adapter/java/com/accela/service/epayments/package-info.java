/**
 * <pre>
 * 
 *  Accela Automation
 *  File: package-info.java
 * 
 *  Accela, Inc.
 *  Copyright (C): 2013
 * 
 *  Description:
 *  
 * </pre>
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://epayments.service.accela.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.accela.service.epayments;
