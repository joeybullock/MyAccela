package com.accela.ws.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

/**
 * <pre>
 * 
 * Accela Automation
 * File: EPayments3.java
 * 
 * Accela, Inc.
 * Copyright (C): 2013
 * 
 * Description:
 * 
 * 
 * </pre>
 */
 
@WebService(targetNamespace = "http://service.ws.accela.com", name = "EPayments3")
@XmlSeeAlso({ObjectFactory.class,com.accela.service.epayments.ObjectFactory.class})
public interface EPayments3 {

    @WebResult(name = "makePaymentReturn", targetNamespace = "http://service.ws.accela.com")
    @RequestWrapper(localName = "makePayment", targetNamespace = "http://service.ws.accela.com", className = "com.accela.ws.service.MakePayment")
    @ResponseWrapper(localName = "makePaymentResponse", targetNamespace = "http://service.ws.accela.com", className = "com.accela.ws.service.MakePaymentResponse")
    @WebMethod(action = "http://service.ws.accela.com/EPayments3/makePayment")
    public com.accela.service.epayments.EPaymentResult makePayment(
        @WebParam(name = "paymentInfo", targetNamespace = "http://service.ws.accela.com")
        com.accela.service.epayments.EPaymentInfo paymentInfo
    ) throws Exception;

    @WebResult(name = "voidPaymentReturn", targetNamespace = "http://service.ws.accela.com")
    @RequestWrapper(localName = "voidPayment", targetNamespace = "http://service.ws.accela.com", className = "com.accela.ws.service.VoidPayment")
    @ResponseWrapper(localName = "voidPaymentResponse", targetNamespace = "http://service.ws.accela.com", className = "com.accela.ws.service.VoidPaymentResponse")
    @WebMethod(action = "http://service.ws.accela.com/EPayments3/voidPayment")
    public com.accela.service.epayments.EPaymentResult voidPayment(
        @WebParam(name = "paymentInfo", targetNamespace = "http://service.ws.accela.com")
        com.accela.service.epayments.EPaymentInfo paymentInfo
    ) throws Exception;
}
