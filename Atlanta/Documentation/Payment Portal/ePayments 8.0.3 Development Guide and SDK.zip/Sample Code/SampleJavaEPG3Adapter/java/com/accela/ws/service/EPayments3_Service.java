
/*
 * 
 */

package com.accela.ws.service;

import java.net.MalformedURLException;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.WebEndpoint;
import javax.xml.ws.WebServiceClient;
import javax.xml.ws.WebServiceFeature;
import javax.xml.ws.Service;

/**
 * <pre>
 * 
 * Accela Automation
 * File: EPayments3_Service.java
 * 
 * Accela, Inc.
 * Copyright (C): 2013
 * 
 * Description:
 * 
 * 
 * </pre>
 */


@WebServiceClient(name = "EPayments3", 
                  wsdlLocation = "file:/D:/AA7.0.0/av.7.0.0/bin/jboss-4.2.3.GA/bin/EPayments3.wsdl",
                  targetNamespace = "http://service.ws.accela.com") 
public class EPayments3_Service extends Service {

    public final static URL WSDL_LOCATION;
    public final static QName SERVICE = new QName("http://service.ws.accela.com", "EPayments3");
    public final static QName EPayments3Port = new QName("http://service.ws.accela.com", "EPayments3Port");
    static {
        URL url = null;
        try {
            url = new URL("file:/D:/AA7.0.0/av.7.0.0/bin/jboss-4.2.3.GA/bin/EPayments3.wsdl");
        } catch (MalformedURLException e) {
            System.err.println("Can not initialize the default wsdl from file:/D:/AA7.0.0/av.7.0.0/bin/jboss-4.2.3.GA/bin/EPayments3.wsdl");
            // e.printStackTrace();
        }
        WSDL_LOCATION = url;
    }

    public EPayments3_Service(URL wsdlLocation) {
        super(wsdlLocation, SERVICE);
    }

    public EPayments3_Service(URL wsdlLocation, QName serviceName) {
        super(wsdlLocation, serviceName);
    }

    public EPayments3_Service() {
        super(WSDL_LOCATION, SERVICE);
    }

    /**
     * 
     * @return
     *     returns EPayments3
     */
    @WebEndpoint(name = "EPayments3Port")
    public EPayments3 getEPayments3Port() {
        return super.getPort(EPayments3Port, EPayments3.class);
    }

    /**
     * 
     * @param features
     *     A list of {@link javax.xml.ws.WebServiceFeature} to configure on the proxy.  Supported features not in the <code>features</code> parameter will have their default values.
     * @return
     *     returns EPayments3
     */
    @WebEndpoint(name = "EPayments3Port")
    public EPayments3 getEPayments3Port(WebServiceFeature... features) {
        return super.getPort(EPayments3Port, EPayments3.class, features);
    }

}
