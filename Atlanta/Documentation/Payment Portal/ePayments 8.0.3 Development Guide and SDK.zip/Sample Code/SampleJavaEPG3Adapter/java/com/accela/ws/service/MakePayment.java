
package com.accela.ws.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.accela.service.epayments.EPaymentInfo;


/**
 * <pre>
 * 
 * Accela Automation
 * File: MakePayment.java
 * 
 * Accela, Inc.
 * Copyright (C): 2013
 * 
 * Description:
 * 
 * 
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "paymentInfo"
})
@XmlRootElement(name = "makePayment")
public class MakePayment {

    @XmlElement(required = true)
    protected EPaymentInfo paymentInfo;

    /**
     * Gets the value of the paymentInfo property.
     * 
     * @return
     *     possible object is
     *     {@link EPaymentInfo }
     *     
     */
    public EPaymentInfo getPaymentInfo() {
        return paymentInfo;
    }

    /**
     * Sets the value of the paymentInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link EPaymentInfo }
     *     
     */
    public void setPaymentInfo(EPaymentInfo value) {
        this.paymentInfo = value;
    }

}
