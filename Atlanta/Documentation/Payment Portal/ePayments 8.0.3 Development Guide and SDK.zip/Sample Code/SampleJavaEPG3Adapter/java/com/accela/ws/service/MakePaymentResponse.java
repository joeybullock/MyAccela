
package com.accela.ws.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.accela.service.epayments.EPaymentResult;


/**
 * <pre>
 * 
 * Accela Automation
 * File: MakePaymentResponse.java
 * 
 * Accela, Inc.
 * Copyright (C): 2013
 * 
 * Description:
 * 
 * 
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "makePaymentReturn"
})
@XmlRootElement(name = "makePaymentResponse")
public class MakePaymentResponse {

    @XmlElement(required = true)
    protected EPaymentResult makePaymentReturn;

    /**
     * Gets the value of the makePaymentReturn property.
     * 
     * @return
     *     possible object is
     *     {@link EPaymentResult }
     *     
     */
    public EPaymentResult getMakePaymentReturn() {
        return makePaymentReturn;
    }

    /**
     * Sets the value of the makePaymentReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link EPaymentResult }
     *     
     */
    public void setMakePaymentReturn(EPaymentResult value) {
        this.makePaymentReturn = value;
    }

}
