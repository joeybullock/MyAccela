
package com.accela.ws.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.accela.service.epayments.EPaymentResult;


/**
 * <pre>
 * 
 * Accela Automation
 * File: VoidPaymentResponse.java
 * 
 * Accela, Inc.
 * Copyright (C): 2013
 * 
 * Description:
 * 
 * 
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "voidPaymentReturn"
})
@XmlRootElement(name = "voidPaymentResponse")
public class VoidPaymentResponse {

    @XmlElement(required = true)
    protected EPaymentResult voidPaymentReturn;

    /**
     * Gets the value of the voidPaymentReturn property.
     * 
     * @return
     *     possible object is
     *     {@link EPaymentResult }
     *     
     */
    public EPaymentResult getVoidPaymentReturn() {
        return voidPaymentReturn;
    }

    /**
     * Sets the value of the voidPaymentReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link EPaymentResult }
     *     
     */
    public void setVoidPaymentReturn(EPaymentResult value) {
        this.voidPaymentReturn = value;
    }

}
