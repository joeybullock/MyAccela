
/**
 * Please modify this class to meet your needs
 * This class is not complete
 */

package com.accela.ws.service.epayments3;

import java.util.logging.Logger;

import com.accela.service.epayments.EPaymentResult;
import com.accela.service.epayments.Map;
import com.accela.ws.service.EPayments3;

/**
 * <pre>
 * 
 * Accela Automation
 * File: EPayments3PayPalImpl.java
 * 
 * Accela, Inc.
 * Copyright (C): 2013
 * 
 * Description:
 * 
 * 
 * </pre>
 */

@javax.jws.WebService(
                      serviceName = "EPayments3",
                      portName = "EPayments3Port",
                      targetNamespace = "http://service.ws.accela.com",
                      endpointInterface = "com.accela.ws.service.EPayments3")
                      
public class EPayments3PayPalImpl implements EPayments3 {

    private static final Logger LOG = Logger.getLogger(EPayments3PayPalImpl.class.getName());

    /* (non-Javadoc)
     * @see com.accela.ws.service.EPayments3#makePayment(com.accela.service.epayments.EPaymentInfo  paymentInfo )*
     */
    public com.accela.service.epayments.EPaymentResult makePayment(com.accela.service.epayments.EPaymentInfo paymentInfo) throws Exception { 
        LOG.info("Executing operation makePayment");
        System.out.println(paymentInfo);
        if (paymentInfo.getConfigData() == null || paymentInfo.getConfigData().getItem().size() < 0)
		{
			throw new Exception("config data is empty!!");
		}
		if (paymentInfo.getPaymentData() == null || paymentInfo.getPaymentData().getItem().size() < 0)
		{
			throw new Exception("payment data is empty!!");
		}


	        //Begin Implemention for EPayment
           

        	//End Implemention for EPayment  



		Map configDataMap = paymentInfo.getConfigData();
		EPaymentResult result = new EPaymentResult();
		result.setReturnCode("0");
		result.setReturnMap(configDataMap);
		return result;
    }

    /* (non-Javadoc)
     * @see com.accela.ws.service.EPayments3#voidPayment(com.accela.service.epayments.EPaymentInfo  paymentInfo )*
     */
    public com.accela.service.epayments.EPaymentResult voidPayment(com.accela.service.epayments.EPaymentInfo paymentInfo) throws Exception { 
        LOG.info("Executing operation voidPayment");
        System.out.println(paymentInfo);
        if (paymentInfo.getConfigData() == null || paymentInfo.getConfigData().getItem().size() < 0)
		{
			throw new Exception("config data is empty!!");
		}
		if (paymentInfo.getPaymentData() == null || paymentInfo.getPaymentData().getItem().size() < 0)
		{
			throw new Exception("payment data is empty!!");
		}

	        //Begin Implemention for EPayment
           

        	//End Implemention for EPayment  


		Map configDataMap = paymentInfo.getConfigData();
		EPaymentResult result = new EPaymentResult();
		result.setReturnCode("0");
		result.setReturnMap(configDataMap);
		return result;
    }

}
