DECLARE
	HAVE_ADAPTER_REC	NUMBER;
	SEQ                 NUMBER;			---SEQ for XPOLICY_SEQ
	AGENCY_ID			VARCHAR2(200);	---agency SERV_PROV_CODE
	ADAPTER_NAME		VARCHAR2(50);	---Adapter Name
	ADAPTER_CONF		VARCHAR2(1000);	---Adapter Configuration
	GATEWAY_CONF		VARCHAR2(1000);	---Gateway Host Configuaration
	PROXY_CONF			VARCHAR2(1000);	---Proxy Server Configuration for accessing Gateway
	MERCHANT_CONF       VARCHAR2(1000);	---Merchant Account information 
	PAYMENT_CONF		VARCHAR2(1000);	---payment info (Just ContryCode=US for PayPal Payflow Pro 43)
BEGIN
  ---init
  ---@TODO: replace me with SERV_PROV_CODE, e.g:'FLAGSTAFF'
  AGENCY_ID		:='FLAGSTAFF';
  ---@TODO: replace me with the name of your ${customer adapter}_Live, e.g. FirstData_Live
  ADAPTER_NAME 	:='MyEPayments3Adapter_Live';
  ---@TODO: set ADAPTER_CONF value to Adapter=EPayments3;AdapterURL=${AdapterURL} for an epayments3.wsdl implementation. Set Adapter=EPayments for a pre-6.7.0 adapter.
  ADAPTER_CONF	:='Adapter=EPayments3;AdapterURL=${AdapterURL}';
  ---@TODO: set the GATEWAY_CONF value to your gateway host access information.
  GATEWAY_CONF	:='${MyHostGatewayConfiguration}';
  ---@TODO: replace me with your custom merchant data configuration
  MERCHANT_CONF	:='${MyHostMerchantConfiguration}';
  ---@TODO: replace me with your country code and, optionally, your amount and convenience fee codes.
  ---@Note: Set to '' for a pre-6.7.0 epayments.wsdl implementation because Pre-6.7.0 custom EPayments (epayments.wsdl) implementations do not use this configuration.
  PAYMENT_CONF	:='CountryCode=US';
  ---PAYMENT_CONF	:='CountryCode=US;TotalAmountFormula=1,1,-1,1,34.99,34.99,1,1.03,0,1,999999,999999;ConvenienceFeeFormula=0,1,1,1,34.99,34.99,0.03,1.03,0,1,9999999,999999'
  --end init
	HAVE_ADAPTER_REC :=0;
	SELECT count(*) into HAVE_ADAPTER_REC
	FROM XPOLICY
	WHERE SERV_PROV_CODE = AGENCY_ID
	AND POLICY_NAME = 'PaymentAdapterSec'
	AND LEVEL_TYPE = 'Adapter'
	AND LEVEL_DATA = ADAPTER_NAME;
	IF (HAVE_ADAPTER_REC <= 0) THEN  
		-- insert Adapter record
		SELECT T.LAST_NUMBER
		INTO SEQ
		FROM AA_SYS_SEQ T
		WHERE T.SEQUENCE_NAME = 'XPOLICY_SEQ';

		SEQ := SEQ + 1;

		INSERT INTO XPOLICY
			(SERV_PROV_CODE, POLICY_SEQ, POLICY_NAME, LEVEL_TYPE, LEVEL_DATA, DATA1, RIGHT_GRANTED,
			STATUS, REC_DATE, REC_FUL_NAM, REC_STATUS, MENUITEM_CODE, DATA2, DATA3, DATA4, MENU_LEVEL,
			DATA5, RES_ID)
		VALUES
			(AGENCY_ID, SEQ, 'PaymentAdapterSec', 'Adapter', ADAPTER_NAME, ADAPTER_CONF, 'F',
			'A', SYSDATE, 'ADMIN', 'A', '', GATEWAY_CONF || PROXY_CONF, MERCHANT_CONF, PAYMENT_CONF,
			'', '', '');

		UPDATE AA_SYS_SEQ SET LAST_NUMBER = SEQ WHERE SEQUENCE_NAME = 'XPOLICY_SEQ';
	END IF;
	UPDATE XPOLICY
	SET 
		DATA1=ADAPTER_CONF,
		DATA2=GATEWAY_CONF || PROXY_CONF,
		DATA3=MERCHANT_CONF,
		DATA4=PAYMENT_CONF,
		REC_DATE=SYSDATE,
		REC_FUL_NAM='ADMIN'
	WHERE SERV_PROV_CODE = AGENCY_ID
	AND POLICY_NAME = 'PaymentAdapterSec'
	AND LEVEL_TYPE = 'Adapter'
	AND LEVEL_DATA = ADAPTER_NAME;
	
  COMMIT;
END;