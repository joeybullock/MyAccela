DECLARE
	HAVE_ADAPTER_REC	NUMBER;
	SEQ                 NUMBER;			---SEQ for XPOLICY_SEQ
	AGENCY_ID			VARCHAR2(200);	---agency SERV_PROV_CODE
	ADAPTER_NAME		VARCHAR2(50);	---Adapter Name
	ADAPTER_CONF		VARCHAR2(1000);	---Adapter Configuration
	GATEWAY_CONF		VARCHAR2(1000);	---Gateway Host Configuaration
	
	MERCHANT_CONF       VARCHAR2(1000);	---payment Parameter,e.g :ApplicationID=1234;MessageVersion=2.2  
	
BEGIN
  ---init
  ---@TODO: replace me with SERV_PROV_CODE, e.g:'FLAGSTAFF'
  AGENCY_ID		:='FLAGSTAFF';
  ---@TODO: replace me with ApplicationID=${ApplicationID};MessageVersion=${MessageVersion}'
  MERCHANT_CONF	:='ApplicationID=;MessageVersion='; 

  ADAPTER_NAME 	:='Govolution_Live';
  ADAPTER_CONF	:='Adapter=Redirect';
  GATEWAY_CONF	:='HostURL=https://www.velocitypayment.com/vrelay/verify.do';
  --end init
	HAVE_ADAPTER_REC :=0;
	SELECT count(*) into HAVE_ADAPTER_REC
	FROM XPOLICY
	WHERE SERV_PROV_CODE = AGENCY_ID
	AND POLICY_NAME = 'PaymentAdapterSec'
	AND LEVEL_TYPE = 'Adapter'
	AND LEVEL_DATA = ADAPTER_NAME;
	IF (HAVE_ADAPTER_REC <= 0) THEN  
		-- insert Adapter record
		SELECT T.LAST_NUMBER
		INTO SEQ
		FROM AA_SYS_SEQ T
		WHERE T.SEQUENCE_NAME = 'XPOLICY_SEQ';

		SEQ := SEQ + 1;

		INSERT INTO XPOLICY
			(SERV_PROV_CODE, POLICY_SEQ, POLICY_NAME, LEVEL_TYPE, LEVEL_DATA, DATA1, RIGHT_GRANTED,
			STATUS, REC_DATE, REC_FUL_NAM, REC_STATUS, MENUITEM_CODE, DATA2, DATA3, DATA4, MENU_LEVEL,
			DATA5, RES_ID)
		VALUES
			(AGENCY_ID, SEQ, 'PaymentAdapterSec', 'Adapter', ADAPTER_NAME, ADAPTER_CONF, 'F',
			'A', SYSDATE, 'ADMIN', 'A', '', GATEWAY_CONF , '', MERCHANT_CONF ,
			'', '', '');

		UPDATE AA_SYS_SEQ SET LAST_NUMBER = SEQ WHERE SEQUENCE_NAME = 'XPOLICY_SEQ';
	END IF;
	UPDATE XPOLICY
	SET 
		DATA1=ADAPTER_CONF,
		DATA2=GATEWAY_CONF ,
		DATA3='',
		DATA4=MERCHANT_CONF,
		REC_DATE=SYSDATE,
		REC_FUL_NAM='ADMIN'
	WHERE SERV_PROV_CODE = AGENCY_ID
	AND POLICY_NAME = 'PaymentAdapterSec'
	AND LEVEL_TYPE = 'Adapter'
	AND LEVEL_DATA = ADAPTER_NAME;
	
  COMMIT;
END;