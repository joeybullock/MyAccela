DECLARE @HAVE_ADAPTER_REC	FLOAT;
DECLARE @SEQ                 FLOAT;			---SEQ for XPOLICY_SEQ
DECLARE @AGENCY_ID			VARCHAR(200);	---agency SERV_PROV_CODE
DECLARE @ADAPTER_NAME		VARCHAR(50);	---Adapter Name
DECLARE @ADAPTER_CONF		VARCHAR(1000);	---Adapter Configuration
DECLARE @GATEWAY_CONF		VARCHAR(1000);	---Gateway Host Configuaration	
DECLARE @MERCHANT_CONF       VARCHAR(1000);	---payment Parameter information 
DECLARE @PAYMENT_CONF		VARCHAR(1000);	---payment info, eg. 'ProductID=0123456789012345678901234567890123456'  
BEGIN
  ---init
  ---@TODO: replace me with SERV_PROV_CODE, e.g:'FLAGSTAFF'
  set @AGENCY_ID		='FLAGSTAFF';
  ---@TODO: replace me with RequestParameterMap and PostbackParameterMap configuration
  set @MERCHANT_CONF	='RequestParameterMap=productId:$$ProductId$$,address1:$$Address1$$,cde-NotiNumb-0:$$CAPID$$,cde-UniqID-1:$$UNIQUEID$$,cityName:$$City$$,email:$$Email$$,first_name:$$FirstName$$,last_name:$$LastName$$,middle_mame:$$MiddleName$$,paymentAmount:$$PaymentAmount$$,phoneNum:$$PhoneNum$$,postalCd:$$Zip$$,provinceCd:$$State$$,cde-Numbof-2:$$NUMBERITEMS$$;PostbackParameterMap=uid:$$UNIQUEID$$,account_type:$$AccountType$$,address1:$$Address1$$,address2:$$Address2$$,address3:$$Address3$$,confirmation:$$Confirmation$$,email:$$Email$$,firstName:$$FirstName$$,lastName:$$LastName$$,middleName:$$MiddleName$$,suffix:$$Suffix$$,telephone:$$PhoneNum$$';
  ---@TODO: replace me with ProductID=${ProductID}
  set @PAYMENT_CONF	='ProductID=';

  set @ADAPTER_NAME 	='OPCoBrandPlus_Live';
  set @ADAPTER_CONF	='Adapter=Redirect';
  set @GATEWAY_CONF	='HostURL=https://www.officialpayments.com/pc_entry_cobrand.jsp;ECheckHostURL=https://www.officialpayments.com/echeck/pc_entry_cobrand.jsp';
   --end init

	set @HAVE_ADAPTER_REC =0;

	SELECT @HAVE_ADAPTER_REC = count(*)
	FROM XPOLICY
	WHERE SERV_PROV_CODE = @AGENCY_ID
	AND POLICY_NAME = 'PaymentAdapterSec'
	AND LEVEL_TYPE = 'Adapter'
	AND LEVEL_DATA = @ADAPTER_NAME;
	IF (@HAVE_ADAPTER_REC <= 0)
	BEGIN
		-- insert Adapter record
		SELECT @SEQ=T.LAST_NUMBER      
		FROM AA_SYS_SEQ T
		WHERE T.SEQUENCE_NAME = 'XPOLICY_SEQ'

		SET @SEQ = @SEQ + 1;

		INSERT INTO XPOLICY
			(SERV_PROV_CODE, POLICY_SEQ, POLICY_NAME, LEVEL_TYPE, LEVEL_DATA, DATA1, RIGHT_GRANTED,
			STATUS, REC_DATE, REC_FUL_NAM, REC_STATUS, MENUITEM_CODE, DATA2, DATA3, DATA4, MENU_LEVEL,
			DATA5, RES_ID)
		VALUES
			(@AGENCY_ID, @SEQ, 'PaymentAdapterSec', 'Adapter', @ADAPTER_NAME, @ADAPTER_CONF, 'F',
			'A', GETDATE(), 'ADMIN', 'A', '', @GATEWAY_CONF , @MERCHANT_CONF, @PAYMENT_CONF,
			'', '', '');

	UPDATE AA_SYS_SEQ SET LAST_NUMBER = @SEQ WHERE SEQUENCE_NAME = 'XPOLICY_SEQ'
	END
	
	UPDATE XPOLICY
	SET 
		DATA1=@ADAPTER_CONF,
		DATA2=@GATEWAY_CONF ,
		DATA3=@MERCHANT_CONF,
		DATA4=@PAYMENT_CONF,
		REC_DATE=GETDATE(),
		REC_FUL_NAM='ADMIN'
	WHERE SERV_PROV_CODE = @AGENCY_ID
	AND POLICY_NAME = 'PaymentAdapterSec'
	AND LEVEL_TYPE = 'Adapter'
	AND LEVEL_DATA = @ADAPTER_NAME;
	
	--commit
END