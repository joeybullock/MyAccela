DECLARE
	HAVE_ADAPTER_REC	NUMBER;
	SEQ                 NUMBER;			---SEQ for XPOLICY_SEQ
	AGENCY_ID			VARCHAR2(200);	---agency SERV_PROV_CODE
	ADAPTER_NAME		VARCHAR2(50);	---Adapter Name
	ADAPTER_CONF		VARCHAR2(1000);	---Adapter Configuration
	GATEWAY_CONF		VARCHAR2(1000);	---Gateway Host Configuaration
	
	MERCHANT_CONF       VARCHAR2(1000);	---Merchant Account information, e.g. 'ClientID=0123456789012345678901234567890123456;ProductID=0123456789012345678901234567890123456;CustomFieldMap=cde-NotiNumb-0:$$RequestID$$,cde-UniqID-1:$$PaymentTransactionID$$,cde-Text-1:$$PaymentComment$$,cde-WateBill-0:$$UserID$$'
	PAYMENT_CONF		VARCHAR2(1000);	---payment info 
BEGIN
  ---init
  ---@TODO: replace me with SERV_PROV_CODE, e.g:'FLAGSTAFF'
  AGENCY_ID		:='FLAGSTAFF';
  ---@TODO: replace me with ClientID=${ClientID};ProductID=${ProductID}
  MERCHANT_CONF	:='ClientID=;ProductID=;CustomFieldMap=cde-NotiNumb-0:$$RequestID$$,cde-UniqID-1:$$PaymentTransactionID$$,cde-Text-1:$$PaymentComment$$,cde-WateBill-0:$$UserID$$';
  ----@TODO: replace me with CountryCode=${CountryCode};TotalAmountFormula=${TotalAmountFormula};ConvenienceFeeFormula=${ConvenienceFeeFormula}
  PAYMENT_CONF	:='CountryCode=US;TotalAmountFormula=1,1,-1,1,34.99,34.99,1,1.03,0,1,999999,999999;ConvenienceFeeFormula=0,1,1,1,34.99,34.99,0.03,1.03,0,1,9999999,999999';

  ADAPTER_NAME 	:='OPSTP_Test';
  ADAPTER_CONF	:='Adapter=EPayments3;AdapterURL=${av.biz.url}/av-epayments3-adapters/OfficialPaymentsSTP?wsdl';
  GATEWAY_CONF	:='HOSTADDRESS=https://staging.officialpayments.com/srv/stp';
  
  --end init
	HAVE_ADAPTER_REC :=0;
	SELECT count(*) into HAVE_ADAPTER_REC
	FROM XPOLICY
	WHERE SERV_PROV_CODE = AGENCY_ID
	AND POLICY_NAME = 'PaymentAdapterSec'
	AND LEVEL_TYPE = 'Adapter'
	AND LEVEL_DATA = ADAPTER_NAME;
	IF (HAVE_ADAPTER_REC <= 0) THEN  
		-- insert Adapter record
		SELECT T.LAST_NUMBER
		INTO SEQ
		FROM AA_SYS_SEQ T
		WHERE T.SEQUENCE_NAME = 'XPOLICY_SEQ';

		SEQ := SEQ + 1;

		INSERT INTO XPOLICY
			(SERV_PROV_CODE, POLICY_SEQ, POLICY_NAME, LEVEL_TYPE, LEVEL_DATA, DATA1, RIGHT_GRANTED,
			STATUS, REC_DATE, REC_FUL_NAM, REC_STATUS, MENUITEM_CODE, DATA2, DATA3, DATA4, MENU_LEVEL,
			DATA5, RES_ID)
		VALUES
			(AGENCY_ID, SEQ, 'PaymentAdapterSec', 'Adapter', ADAPTER_NAME, ADAPTER_CONF, 'F',
			'A', SYSDATE, 'ADMIN', 'A', '', GATEWAY_CONF , MERCHANT_CONF, PAYMENT_CONF,
			'', '', '');

		UPDATE AA_SYS_SEQ SET LAST_NUMBER = SEQ WHERE SEQUENCE_NAME = 'XPOLICY_SEQ';
	END IF;
	UPDATE XPOLICY
	SET 
		DATA1=ADAPTER_CONF,
		DATA2=GATEWAY_CONF ,
		DATA3=MERCHANT_CONF,
		DATA4=PAYMENT_CONF,
		REC_DATE=SYSDATE,
		REC_FUL_NAM='ADMIN'
	WHERE SERV_PROV_CODE = AGENCY_ID
	AND POLICY_NAME = 'PaymentAdapterSec'
	AND LEVEL_TYPE = 'Adapter'
	AND LEVEL_DATA = ADAPTER_NAME;
	
  COMMIT;
END;